<?php

/***************************************
 * www.program-o.com
 * PROGRAM O
 * Version: 2.6.8
 * FILE: chatbot/core/user/load_userfunctions.php
 * AUTHOR: Elizabeth Perreau and Dave Morton
 * DATE: MAY 17TH 2014
 * DETAILS: this file contains the includes to load all user function files
 ***************************************/
include_once("handle_user.php");

runDebug(__FILE__, __FUNCTION__, __LINE__, "userfunctions include files loaded", 4);